#include "modules/VehicleManagement.h"
#include "modules/ParkingSlotManagement.h"
#include "modules/FareCalculation.h"
#include "modules/SearchNavigation.h"
#include "modules/ReportingAnalytics.h"
#include "modules/ErrorHandling.h"
#include "modules/FileHandling.h"

#include <iostream>
#include <string>
#include <iomanip>
#include <thread>
#include <chrono>

using namespace std;

VehicleManagement vm;
ParkingSlotManagement psm(5, 10);

void clearScreen() {
    cout << "\033[2J\033[H";
}

void displayLayout() {
    clearScreen();
    cout << "======================================\n";
    cout << "       SMART PARKING SYSTEM\n";
    cout << "======================================\n\n";

    const auto& layout = psm.getLayout();
    cout << "   ";
    for (int c = 0; c < (int)layout[0].size(); ++c)
        cout << setw(3) << c;
    cout << "\n  +";
    for (int c = 0; c < (int)layout[0].size(); ++c)
        cout << "---";
    cout << "+\n";

    for (int r = 0; r < (int)layout.size(); ++r) {
        cout << setw(2) << r << " |";
        for (int c = 0; c < (int)layout[r].size(); ++c) {
            cout << (layout[r][c].occupied ? " # " : " . ");
        }
        cout << "|\n";
    }
    cout << "  +";
    for (int c = 0; c < (int)layout[0].size(); ++c)
        cout << "---";
    cout << "+\n\n";
    cout << "Legend: . = Free   # = Occupied\n\n";
}

void menuRegisterVehicle() {
    string plate, type;
    cout << "Enter License Plate: ";   cin >> plate;
    cout << "Enter Vehicle Type (car/bike/truck): "; cin >> type;

    if (!vm.registerVehicle(plate, type)) {
        cout << "\nPress Enter to continue..."; cin.ignore(); cin.get(); return;
    }

    cout << "Vehicle registered.\n";
    if (psm.isFull()) {
        psm.addToWaitingQueue(plate);
        cout << "Parking full – added to waiting queue.\n";
    } else {
        int r = -1, c = -1, id = -1;
        if (psm.allocateSlot(plate, r, c, id)) {
            auto v = vm.getVehicle(plate);
            if (v) { v->slotRow = r; v->slotCol = c; }
            cout << "Allocated Slot: Row " << r << ", Col " << c << " (ID: " << id << ")\n";
        }
    }
    cout << "\nPress Enter to continue..."; cin.ignore(); cin.get();
}

void menuVehicleExit() {
    string plate;
    cout << "Enter License Plate to Exit: "; cin >> plate;

    auto v = vm.getVehicle(plate);
    if (!v) {
        cout << "Vehicle not found!\n";
    } else {
        if (v->slotRow == -1) {
            cout << "Vehicle was in waiting queue – removed.\n";
        } else {
            if (psm.releaseSlot(v->slotRow, v->slotCol)) {
                cout << "Slot (" << v->slotRow << "," << v->slotCol << ") released.\n";
            } else {
                cout << "Failed to release slot.\n";
            }
        }

        double fare = FareCalculation::calculateFare(*v);
        cout << fixed << setprecision(2);
        cout << "Parking Duration: " << FareCalculation::getMinutesParked(*v) << " minutes\n";
        cout << "Fare: ₹" << fare << "\n";

        vm.removeVehicle(plate);
        cout << "Vehicle removed from system.\n";

        if (!psm.isFull() && psm.processWaitingQueue())
            cout << "One vehicle from waiting queue allocated.\n";
    }
    cout << "\nPress Enter to continue..."; cin.ignore(); cin.get();
}

void menuSearchVehicle() {
    string plate;
    cout << "Enter License Plate to Search: "; cin >> plate;
    auto slot = SearchNavigation::findVehicleSlot(psm.getLayout(), plate);
    if (slot) {
        cout << "Found at Row: " << slot->row << ", Col: " << slot->col
             << " (ID: " << slot->id << ")\n";
    } else {
        cout << "Vehicle not found in parking.\n";
    }
    cout << "\nPress Enter to continue..."; cin.ignore(); cin.get();
}

void menuFindNearestSlot() {
    int er, ec;
    cout << "Enter Entry Gate (Row Col): "; cin >> er >> ec;
    auto slot = SearchNavigation::findNearestSlot(psm.getLayout(), er, ec);
    if (slot) {
        cout << "Nearest Free Slot: Row " << slot->row << ", Col: " << slot->col
             << " (ID: " << slot->id << ")\n";
    } else {
        cout << "No free slot available.\n";
    }
    cout << "\nPress Enter to continue..."; cin.ignore(); cin.get();
}

void menuGenerateReport() {
    cout << ReportingAnalytics::generateDailyReport(vm.getAllVehicles());
    int total = psm.getLayout().size() * psm.getLayout()[0].size();
    int occupied = vm.getAllVehicles().size();
    int free = total - occupied;
    cout << "Total Slots: " << total << "\n";
    cout << "Occupied  : " << occupied << "\n";
    cout << "Free Slots: " << free << "\n";
    cout << "\nPress Enter to continue..."; cin.ignore(); cin.get();
}

void menuSaveData() {
    if (FileHandling::saveParkingData(vm.getAllVehicles(), psm.getLayout()))
        cout << "Parking data saved successfully!\n";
    else
        cout << "Failed to save data.\n";
    cout << "\nPress Enter to continue..."; cin.ignore(); cin.get();
}

void menuLoadData() {
    std::unordered_map<std::string, Vehicle> loadedVehicles;
    std::vector<std::vector<Slot>> loadedLayout;

    if (!FileHandling::loadParkingData(loadedVehicles, loadedLayout)) {
        cout << "No saved data or load failed.\n";
        cout << "\nPress Enter to continue..."; cin.ignore(); cin.get();
        return;
    }

    int rows = loadedLayout.size();
    int cols = (rows > 0) ? loadedLayout[0].size() : 0;
    if (rows == 0 || cols == 0) {
        cout << "Invalid layout in saved file.\n";
        cout << "\nPress Enter to continue..."; cin.ignore(); cin.get();
        return;
    }

    psm = ParkingSlotManagement(loadedLayout);

    vm = VehicleManagement();
    for (const auto& [plate, v] : loadedVehicles) {
        vm.registerVehicle(plate, v.type);
        auto pVeh = vm.getVehicle(plate);
        if (pVeh) {
            pVeh->slotRow   = v.slotRow;
            pVeh->slotCol   = v.slotCol;
            pVeh->entryTime = v.entryTime;
        }
    }

    cout << "Data loaded successfully! (" << rows << "x" << cols << " slots)\n";
    cout << "\nPress Enter to continue..."; cin.ignore(); cin.get();
}

void menuShowAllVehicles() {
    cout << "Registered Vehicles:\n";
    cout << "--------------------------------------------------\n";
    cout << left << setw(15) << "Plate" << setw(10) << "Type"
         << setw(12) << "Slot" << "Parked (min)\n";
    cout << "--------------------------------------------------\n";

    for (const auto& kv : vm.getAllVehicles()) {
        const Vehicle& v = kv.second;
        string slotStr = (v.slotRow == -1) ? "Waiting"
                                          : to_string(v.slotRow) + "," + to_string(v.slotCol);
        int mins = FareCalculation::getMinutesParked(v);
        cout << left << setw(15) << v.licensePlate
             << setw(10) << v.type
             << setw(12) << slotStr
             << mins << "\n";
    }
    cout << "\nPress Enter to continue..."; cin.ignore(); cin.get();
}

void showMenu() {
    displayLayout();
    cout << "MENU:\n";
    cout << "1. Register Vehicle & Allocate Slot\n";
    cout << "2. Vehicle Exit & Generate Bill\n";
    cout << "3. Search Vehicle by Plate\n";
    cout << "4. Find Nearest Free Slot\n";
    cout << "5. Generate Daily Report\n";
    cout << "6. Save Parking Data\n";
    cout << "7. Load Parking Data\n";
    cout << "8. Show All Registered Vehicles\n";
    cout << "9. Exit\n";
    cout << "Choose option: ";
}

int main() {
    int choice;
    while (true) {
        showMenu();
        if (!(cin >> choice)) {
            cin.clear();
            cin.ignore(10000, '\n');
            continue;
        }

        switch (choice) {
            case 1: menuRegisterVehicle(); break;
            case 2: menuVehicleExit();    break;
            case 3: menuSearchVehicle();  break;
            case 4: menuFindNearestSlot();break;
            case 5: menuGenerateReport(); break;
            case 6: menuSaveData();       break;
            case 7: menuLoadData();       break;
            case 8: menuShowAllVehicles();break;
            case 9:
                cout << "Thank you! Exiting...\n";
                return 0;
            default:
                cout << "Invalid choice!\n";
                cout << "Press Enter to continue...";
                cin.ignore(); cin.get();
        }
    }
    return 0;
}
