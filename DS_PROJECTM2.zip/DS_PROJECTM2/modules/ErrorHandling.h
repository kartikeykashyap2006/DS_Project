#ifndef ERRORHANDLING_H
#define ERRORHANDLING_H

#include <string>

enum class ErrorCode {
    SUCCESS,
    VEHICLE_EXISTS,
    VEHICLE_NOT_FOUND,
    PARKING_FULL,
    INVALID_SLOT,
    FILE_ERROR
};

class ErrorHandling {
public:
    static std::string getMessage(ErrorCode code);
    static void logError(ErrorCode code, const std::string& details = "");
};

#endif