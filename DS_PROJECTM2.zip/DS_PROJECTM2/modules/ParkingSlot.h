#ifndef PARKINGSLOT_H
#define PARKINGSLOT_H

#include <string>

struct Slot {
    int id;
    int row, col;
    bool occupied;
    std::string vehiclePlate;

    Slot() : id(0), row(0), col(0), occupied(false), vehiclePlate("") {}
    Slot(int r, int c, int i) : id(i), row(r), col(c), occupied(false), vehiclePlate("") {}
};

#endif