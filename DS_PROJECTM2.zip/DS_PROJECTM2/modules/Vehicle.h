#ifndef VEHICLE_H
#define VEHICLE_H

#include <string>
#include <chrono>

struct Vehicle {
    std::string licensePlate;
    std::string type; 
    std::chrono::steady_clock::time_point entryTime;
    int slotRow, slotCol;

    Vehicle() = default;
    Vehicle(const std::string& plate, const std::string& t)
        : licensePlate(plate), type(t), slotRow(-1), slotCol(-1) {
        entryTime = std::chrono::steady_clock::now();
    }
};

#endif