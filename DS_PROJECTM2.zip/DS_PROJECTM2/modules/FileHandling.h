#ifndef FILEHANDLING_H
#define FILEHANDLING_H

#include "Vehicle.h"
#include "ParkingSlot.h"
#include <string>
#include <unordered_map>
#include <vector>

class FileHandling {
public:
    static bool saveParkingData(const std::unordered_map<std::string, Vehicle>& vehicles,
                                const std::vector<std::vector<Slot>>& layout,
                                const std::string& filename = "data/parking_data.txt");
    static bool loadParkingData(std::unordered_map<std::string, Vehicle>& vehicles,
                                std::vector<std::vector<Slot>>& layout,
                                const std::string& filename = "data/parking_data.txt");
};

#endif