#ifndef SEARCHNAVIGATION_H
#define SEARCHNAVIGATION_H

#include "ParkingSlot.h"
#include <vector>
#include <queue>

struct SlotNode {
    int row, col, dist;
    SlotNode(int r, int c, int d) : row(r), col(c), dist(d) {}
    bool operator>(const SlotNode& other) const { return dist > other.dist; }
};

class SearchNavigation {
public:
    static Slot* findVehicleSlot(const std::vector<std::vector<Slot>>& layout, const std::string& plate);
    static Slot* findNearestSlot(const std::vector<std::vector<Slot>>& layout, int entryRow = 0, int entryCol = 0);
};

#endif