#include "VehicleManagement.h"
#include "ErrorHandling.h"
#include <iostream>

bool VehicleManagement::registerVehicle(const std::string& plate, const std::string& type) {
    if (vehicleMap.find(plate) != vehicleMap.end()) {
        ErrorHandling::logError(ErrorCode::VEHICLE_EXISTS, plate);
        return false;
    }
    vehicleMap[plate] = Vehicle(plate, type);
    return true;
}

bool VehicleManagement::removeVehicle(const std::string& plate) {
    if (vehicleMap.erase(plate) > 0) {
        return true;
    }
    ErrorHandling::logError(ErrorCode::VEHICLE_NOT_FOUND, plate);
    return false;
}

Vehicle* VehicleManagement::getVehicle(const std::string& plate) {
    auto it = vehicleMap.find(plate);
    return (it != vehicleMap.end()) ? &(it->second) : nullptr;
}

bool VehicleManagement::isVehiclePresent(const std::string& plate) const {
    return vehicleMap.find(plate) != vehicleMap.end();
}

const std::unordered_map<std::string, Vehicle>& VehicleManagement::getAllVehicles() const {
    return vehicleMap;
}