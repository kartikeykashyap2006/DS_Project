#ifndef FARECALCULATION_H
#define FARECALCULATION_H

#include "Vehicle.h"
#include <chrono>

class FareCalculation {
public:
    static double calculateFare(const Vehicle& v);
    static int getMinutesParked(const Vehicle& v);
};

#endif