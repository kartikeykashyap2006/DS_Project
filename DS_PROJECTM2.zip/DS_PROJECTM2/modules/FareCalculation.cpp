#include "FareCalculation.h"
#include <chrono>

int FareCalculation::getMinutesParked(const Vehicle& v) {
    auto now = std::chrono::steady_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::minutes>(now - v.entryTime);
    return static_cast<int>(duration.count());
}

double FareCalculation::calculateFare(const Vehicle& v) {
    int minutes = getMinutesParked(v);
    double rate = (v.type == "bike") ? 0.5 : (v.type == "truck") ? 2.0 : 1.0;
    int hours = (minutes + 59) / 60;
    return hours * rate * 50.0;
}