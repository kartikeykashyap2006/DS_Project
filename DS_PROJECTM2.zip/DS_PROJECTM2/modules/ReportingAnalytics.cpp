#include "ReportingAnalytics.h"
#include "FareCalculation.h"
#include <sstream>

int ReportingAnalytics::totalVehicles(const std::unordered_map<std::string, Vehicle>& vehicles) {
    return vehicles.size();
}

double ReportingAnalytics::totalRevenue(const std::unordered_map<std::string, Vehicle>& vehicles) {
    double revenue = 0.0;
    for (const auto& [plate, v] : vehicles)
        revenue += FareCalculation::calculateFare(v);
    return revenue;
}

std::string ReportingAnalytics::generateDailyReport(const std::unordered_map<std::string, Vehicle>& vehicles) {
    std::ostringstream oss;
    oss << "=== DAILY PARKING REPORT ===\n";
    oss << "Total Vehicles: " << totalVehicles(vehicles) << "\n";
    oss << "Total Revenue: ₹" << totalRevenue(vehicles) << "\n";
    oss << "==========================\n";
    return oss.str();
}