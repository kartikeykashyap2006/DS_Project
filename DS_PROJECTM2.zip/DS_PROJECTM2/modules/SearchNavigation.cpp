#include "SearchNavigation.h"
#include <queue>
#include <vector>

Slot* SearchNavigation::findVehicleSlot(const std::vector<std::vector<Slot>>& layout, const std::string& plate) {
    for (const auto& row : layout)
        for (const auto& slot : row)
            if (slot.occupied && slot.vehiclePlate == plate)
                return const_cast<Slot*>(&slot);
    return nullptr;
}

Slot* SearchNavigation::findNearestSlot(const std::vector<std::vector<Slot>>& layout, int entryRow, int entryCol) {
    int rows = layout.size(), cols = layout[0].size();
    std::priority_queue<SlotNode, std::vector<SlotNode>, std::greater<>> pq;
    std::vector<std::vector<bool>> visited(rows, std::vector<bool>(cols, false));

    pq.push(SlotNode(entryRow, entryCol, 0));
    int dr[] = {-1, 0, 1, 0};
    int dc[] = {0, 1, 0, -1};

    while (!pq.empty()) {
        SlotNode curr = pq.top(); pq.pop();
        int r = curr.row, c = curr.col;
        if (r < 0 || r >= rows || c < 0 || c >= cols || visited[r][c]) continue;
        visited[r][c] = true;

        if (!layout[r][c].occupied)
            return const_cast<Slot*>(&layout[r][c]);

        for (int i = 0; i < 4; ++i) {
            int nr = r + dr[i], nc = c + dc[i];
            if (nr >= 0 && nr < rows && nc >= 0 && nc < cols && !visited[nr][nc])
                pq.push(SlotNode(nr, nc, curr.dist + 1));
        }
    }
    return nullptr;
}