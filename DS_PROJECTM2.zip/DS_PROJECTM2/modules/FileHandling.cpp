#include "FileHandling.h"
#include "ErrorHandling.h"
#include <fstream>
#include <sstream>
#include <filesystem>

bool FileHandling::saveParkingData(const std::unordered_map<std::string, Vehicle>& vehicles,
                                   const std::vector<std::vector<Slot>>& layout,
                                   const std::string& filename) {
    std::filesystem::create_directories("data");
    std::ofstream file(filename);
    if (!file) {
        ErrorHandling::logError(ErrorCode::FILE_ERROR, "save");
        return false;
    }

    file << vehicles.size() << "\n";
    for (const auto& [plate, v] : vehicles) {
        file << plate << " " << v.type << " " << v.slotRow << " " << v.slotCol << "\n";
    }

    int rows = layout.size();
    int cols = layout.empty() ? 0 : layout[0].size();
    file << rows << " " << cols << "\n";


    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            const Slot& s = layout[i][j];
            file << s.occupied << " " << s.vehiclePlate << " ";
        }
        file << "\n";
    }

    return true;
}

bool FileHandling::loadParkingData(std::unordered_map<std::string, Vehicle>& vehicles,
                                   std::vector<std::vector<Slot>>& layout,
                                   const std::string& filename) {
    std::ifstream file(filename);
    if (!file) return false;

    vehicles.clear();
    layout.clear();

    int numVehicles = 0;
    if (!(file >> numVehicles)) return false;
    std::string line;
    std::getline(file, line);

    for (int i = 0; i < numVehicles; ++i) {
        if (!std::getline(file, line)) break;
        std::istringstream iss(line);
        std::string plate, type;
        int r = -1, c = -1;
        if (iss >> plate >> type >> r >> c) {
            Vehicle v(plate, type);
            v.slotRow = r; v.slotCol = c;
            vehicles[plate] = v;
        }
    }

    int rows = 0, cols = 0;
    if (!(file >> rows >> cols)) return false;
    std::getline(file, line);
    if (rows <= 0 || cols <= 0) return false;

    layout.resize(rows, std::vector<Slot>(cols));

    int id = 1;
    for (int i = 0; i < rows; ++i) {
        if (!std::getline(file, line)) break;
        std::istringstream iss(line);
        for (int j = 0; j < cols; ++j) {
            bool occupied;
            std::string plate;
            if (iss >> occupied >> plate) {
                layout[i][j] = Slot(i, j, id++);
                layout[i][j].occupied = occupied;
                layout[i][j].vehiclePlate = plate;
            }
        }
    }

    return true;
}