#ifndef PARKINGSLOTMANAGEMENT_H
#define PARKINGSLOTMANAGEMENT_H

#include "ParkingSlot.h"
#include "Vehicle.h"
#include <vector>
#include <queue>
#include <stack>

class ParkingSlotManagement {
private:
    int rows, cols;
    std::vector<std::vector<Slot>> layout;
    std::queue<std::pair<int, int>> entryQueue;
    std::stack<std::pair<int, int>> compactStack;

public:
    ParkingSlotManagement(int r = 5, int c = 10);
    ParkingSlotManagement(const std::vector<std::vector<Slot>>& existingLayout); 

    bool allocateSlot(const std::string& plate, int& row, int& col, int& slotId);
    bool releaseSlot(int row, int col);
    bool isFull() const;
    bool isEmpty() const;
    const std::vector<std::vector<Slot>>& getLayout() const;
    void addToWaitingQueue(const std::string& plate);
    bool processWaitingQueue();
    Slot* getSlot(int row, int col);
};

#endif