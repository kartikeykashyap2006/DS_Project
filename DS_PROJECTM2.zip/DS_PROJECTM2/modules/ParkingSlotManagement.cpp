#include "ParkingSlotManagement.h"
#include "ErrorHandling.h"
#include <iostream>

ParkingSlotManagement::ParkingSlotManagement(int r, int c) : rows(r), cols(c) {
    layout.resize(rows, std::vector<Slot>(cols));
    int id = 1;
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            layout[i][j] = Slot(i, j, id++);
            if (i == 0 && j < 3) compactStack.push({i, j});
        }
    }
}

ParkingSlotManagement::ParkingSlotManagement(const std::vector<std::vector<Slot>>& existingLayout)
    : rows(existingLayout.size()),
      cols(existingLayout.empty() ? 0 : existingLayout[0].size()),
      layout(existingLayout) {
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            if (i == 0 && j < 3 && !layout[i][j].occupied) {
                compactStack.push({i, j});
            }
        }
    }
}

bool ParkingSlotManagement::allocateSlot(const std::string& plate, int& row, int& col, int& slotId) {
    if (!compactStack.empty()) {
        auto [r, c] = compactStack.top(); compactStack.pop();
        if (!layout[r][c].occupied) {
            layout[r][c].occupied = true;
            layout[r][c].vehiclePlate = plate;
            row = r; col = c; slotId = layout[r][c].id;
            return true;
        }
    }

    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            if (!layout[i][j].occupied) {
                layout[i][j].occupied = true;
                layout[i][j].vehiclePlate = plate;
                row = i; col = j; slotId = layout[i][j].id;
                return true;
            }
        }
    }
    ErrorHandling::logError(ErrorCode::PARKING_FULL);
    return false;
}

bool ParkingSlotManagement::releaseSlot(int row, int col) {
    if (row < 0 || row >= rows || col < 0 || col >= cols) {
        ErrorHandling::logError(ErrorCode::INVALID_SLOT);
        return false;
    }
    if (!layout[row][col].occupied) {
        ErrorHandling::logError(ErrorCode::INVALID_SLOT);
        return false;
    }
    layout[row][col].occupied = false;
    layout[row][col].vehiclePlate = "";
    if (row == 0 && col < 3) compactStack.push({row, col});
    return true;
}

bool ParkingSlotManagement::isFull() const {
    for (const auto& r : layout)
        for (const auto& s : r)
            if (!s.occupied) return false;
    return true;
}

bool ParkingSlotManagement::isEmpty() const {
    for (const auto& r : layout)
        for (const auto& s : r)
            if (s.occupied) return false;
    return true;
}

const std::vector<std::vector<Slot>>& ParkingSlotManagement::getLayout() const {
    return layout;
}

void ParkingSlotManagement::addToWaitingQueue(const std::string& plate) {
    entryQueue.push({-1, -1});
}

bool ParkingSlotManagement::processWaitingQueue() {
    if (entryQueue.empty() || isFull()) return false;
    entryQueue.pop();
    return true;
}

Slot* ParkingSlotManagement::getSlot(int row, int col) {
    if (row >= 0 && row < rows && col >= 0 && col < cols)
        return &layout[row][col];
    return nullptr;
}
