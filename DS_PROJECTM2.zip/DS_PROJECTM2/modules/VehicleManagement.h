#ifndef VEHICLEMANAGEMENT_H
#define VEHICLEMANAGEMENT_H

#include "Vehicle.h"
#include <unordered_map>
#include <string>

class VehicleManagement {
private:
    std::unordered_map<std::string, Vehicle> vehicleMap;

public:
    bool registerVehicle(const std::string& plate, const std::string& type);
    bool removeVehicle(const std::string& plate);
    Vehicle* getVehicle(const std::string& plate);
    bool isVehiclePresent(const std::string& plate) const;
    const std::unordered_map<std::string, Vehicle>& getAllVehicles() const;
};

#endif