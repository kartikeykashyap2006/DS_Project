#include "ErrorHandling.h"
#include <iostream>

std::string ErrorHandling::getMessage(ErrorCode code) {
    switch (code) {
        case ErrorCode::SUCCESS: return "Success";
        case ErrorCode::VEHICLE_EXISTS: return "Vehicle already registered";
        case ErrorCode::VEHICLE_NOT_FOUND: return "Vehicle not found";
        case ErrorCode::PARKING_FULL: return "Parking is full";
        case ErrorCode::INVALID_SLOT: return "Invalid slot";
        case ErrorCode::FILE_ERROR: return "File error";
        default: return "Unknown error";
    }
}

void ErrorHandling::logError(ErrorCode code, const std::string& details) {
    std::cerr << "[ERROR] " << getMessage(code);
    if (!details.empty()) std::cerr << ": " << details;
    std::cerr << std::endl;
}