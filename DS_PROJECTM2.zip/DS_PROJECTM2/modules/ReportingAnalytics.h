#ifndef REPORTINGANALYTICS_H
#define REPORTINGANALYTICS_H

#include "Vehicle.h"
#include <unordered_map>
#include <string>

class ReportingAnalytics {
public:
    static int totalVehicles(const std::unordered_map<std::string, Vehicle>& vehicles);
    static double totalRevenue(const std::unordered_map<std::string, Vehicle>& vehicles);
    static std::string generateDailyReport(const std::unordered_map<std::string, Vehicle>& vehicles);
};

#endif